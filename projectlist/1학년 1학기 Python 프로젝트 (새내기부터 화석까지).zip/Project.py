# _*_coding:utf_8 _*_
# UTF-8 encoding when using korean

from tkinter import *
from tkinter import font
from PIL import Image
from PIL import ImageTk
import random, sys, time

class App_0(Frame):
    def __init__(self,master):
        super().__init__(master)
        self.grid(padx=0, pady=0)
        self.title()

    def title(self):
        image = Image.open("타이틀.png")
        title_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=title_image)
        self.image.pack()

        title.after(3000, self.update())

        title.quit()
        title.destroy()

class App_1(Frame):
    def __init__(self,master):
        super().__init__(master)
        self.grid(padx=30, pady=20)
        self.setting_1()

    def setting_1(self):
        Label(self, font=("돋움 20 bold"), text="당신의 새내기에게 이름을 지어주세요.").pack(padx=40, pady=20)
        self.entry = Entry(self, font=("바탕 18"), width=15, justify=CENTER)
        self.entry.pack(pady=20)
        Button(self, font=("바탕 13 bold"), text="확인", command=self.naming).pack()

    def naming(self):
        global name
        name = self.entry.get()
        if name.isalpha() == False:
            error_1 = Label(self, fg="red", font=("굴림 15 bold"), text="다시 입력해주세요.")
            error_1.pack(pady=10)

            ready.after(1500, self.update())

            error_1.destroy()
        else:
            App_2(ready)
            self.destroy()

class App_2(Frame):
    def __init__(self,master):
        super().__init__(master)
        self.grid(padx=30, pady=20)
        self.setting_2()

    def setting_2(self):
        Label(self, font=("돋움 20 bold"), text="새내기의 성별은 무엇인가요?").pack(padx=100,pady=20)
        Button(self, font=("바탕 15 bold"), text="남자", command=self.gender_1).pack(pady=10)
        Button(self, font=("바탕 15 bold"), text="여자", command=self.gender_2).pack(pady=10)

    def gender_1(self):
        global gender
        gender = "남자"
        App_3(ready)
        self.destroy()

    def gender_2(self):
        global gender
        gender = "여자"
        App_3(ready)
        self.destroy()

class App_3(Frame):
    def __init__(self,master):
        super().__init__(master)
        self.grid(padx=30, pady=20)
        self.setting_3()

    def setting_3(self):
        Label(self, font=("돋움 20 bold"), text="새내기의 생일이 있는 달을 입력해주세요.").pack(padx=25, pady=20)
        self.entry = Entry(self, font=("바탕 18"), width=15, justify=CENTER)
        self.entry.pack(pady=20)
        Button(self, font=("바탕 13 bold"), text="확인", command=self.birthm).pack()

    def birthm(self):
        global birth_month
        birth_month = self.entry.get()
        if birth_month.isdigit() == False:
            error_1 = Label(self, fg="red", font=("굴림 15 bold"), text="다시 입력해주세요.")
            error_1.pack(pady=10)

            ready.after(1500, self.update())

            error_1.destroy()
        else:
            if not 0 < int(birth_month) < 13:
                error_1 = Label(self, fg="red", font=("굴림 15 bold"), text="다시 입력해주세요.")
                error_1.pack(pady=10)

                ready.after(1500, self.update())

                error_1.destroy()
            else:
                App_4(ready)
                self.destroy()

class App_4(Frame):
    def __init__(self,master):
        super().__init__(master)
        self.grid(padx=30, pady=20)
        self.setting_4()

    def setting_4(self):
        Label(self, font=("돋움 18 bold"), text="당신의 새내기는 통학러입니까, 자취러입니까?").pack(padx=30, pady=20)
        Button(self, font=("바탕 15 bold"), text="통학러", command=self.comm_1).pack(pady=10)
        Button(self, font=("바탕 15 bold"), text="자취러", command=self.comm_2).pack(pady=10)

    def comm_1(self):
        global comm
        comm = "통학"
        ready.destroy()
        ready.quit()

    def comm_2(self):
        global comm
        comm = "자취"
        ready.destroy()
        ready.quit()

class App(Frame):
    def __init__(self, master):
        super().__init__(master)
        self.grid(padx=30, pady=20)

        self.name = name
        self.gender = gender
        self.birth_month = birth_month
        self.comm = comm

        if self.comm == "자취":
            self.stamina = 30
            self.intellect = 30
            self.attract = 30
            self.character = 30
            self.stress = 0
            self.money = 300000
        elif self.comm == "통학":
            self.stamina = 0
            self.intellect = 0
            self.attract = 0
            self.character = 0
            self.stress = 0
            self.money = 300000

        self.month = 3
        self.date = 2
        self.act_count =0
        self.score = 0
        self.love_count =0

        self.create_widgets()
        self.menu()

    def create_widgets(self):
        self.day_list = ["월요일","화요일","수요일","목요일","금요일"]
        self.i = 3

        self.dt = Label(self, font=("굴림 20 bold"), text=str(self.month)+"월 "+str(self.date)+"일 "+self.day_list[self.i])

        self.stm = Label(self, font=("굴림 15 bold"), text="체력 : "+str(self.stamina))
        self.int = Label(self, font=("굴림 15 bold"), text="지능 : "+str(self.intellect))
        self.atr = Label(self, font=("굴림 15 bold"), text="매력 : "+str(self.attract))
        self.cha = Label(self, font=("굴림 15 bold"), text="인성 : "+str(self.character))
        self.str = Label(self, font=("굴림 15 bold"), text="스트레스 : "+str(self.stress))
        self.mon = Label(self, font=("굴림 15 bold"), text="재력 : "+str(self.money))

        self.dt.grid(row=0, column=0, padx=10, pady=10)

        self.stm.grid(row=1, column=10, padx=10)
        self.int.grid(row=2, column=10, padx=10)
        self.atr.grid(row=3, column=10, padx=10)
        self.cha.grid(row=4, column=10, padx=10)
        self.str.grid(row=5, column=10, padx=10)
        self.mon.grid(row=6, column=10, padx=10)

    def menu(self):
        if self.month == 6 and self.date == 20 and self.act_count == 3:
            self.ending()
        else:

            self.schedule = Label(self, font=("굴림 18"), text=str(self.act_count + 1) + "번째 스케쥴을 선택하세요!(하루에 3번 행동!)")

            if self.act_count == 3:
                self.act_count = 0
                if self.i == 4:
                    self.i = 0
                    self.date += 3
                    self.dt.configure(text=str(self.month)+"월 "+str(self.date)+"일 "+self.day_list[self.i])
                    self.schedule.configure(text=str(self.act_count+1)+"번째 스케쥴을 선택하세요!(하루에 3번 행동!)")
                else:
                    self.i += 1
                    self.date += 1
                    self.dt.configure(text=str(self.month)+"월 "+str(self.date)+"일 "+self.day_list[self.i])
                    self.schedule.configure(text=str(self.act_count+1)+"번째 스케쥴을 선택하세요!(하루에 3번 행동!)")

            if self.month in [3,5]:
                if self.date > 31:
                    self.date -= 31
                    self.month += 1
                    self.dt.configure(text=str(self.month)+"월 "+str(self.date)+"일 "+self.day_list[self.i])
            elif self.month == 4:
                if self.date > 30:
                    self.date -= 30
                    self.month += 1
                    self.dt.configure(text=str(self.month)+"월 "+str(self.date)+"일 "+self.day_list[self.i])

            self.button_1 = Button(self, font=("돋움 15 bold"), text="식사", command=self.eating)
            self.button_2 = Button(self, font=("돋움 15 bold"), text="여가생활", command=self.activity)
            self.button_3 = Button(self, font=("돋움 15 bold"), text="수업", command=self.lesson)

            if self.love_count == 0:
                self.button_4 = Button(self, font=("돋움 15 bold"), text="프로포즈", command=self.propose)
            elif self.love_count == 1:
                self.button_4 = Button(self, font=("돋움 15 bold"), text="데이트", command=self.love)

            self.button_fest = Button(self, font=("돋움 15 bold"), text="축제", command=self.festival)

            self.schedule.grid(row=2, column=0, padx=10, pady=10)
            self.button_1.grid(row=4, column=0, padx=10, pady=10)
            self.button_2.grid(row=5, column=0, padx=10, pady=10)
            self.button_3.grid(row=6, column=0, padx=10, pady=10)
            self.button_4.grid(row=7, column=0, padx=10, pady=10)

            if self.month == 5 and self.date == 24:
                self.button_fest.grid(row=8, column=0, padx=10, pady=10)
    #식사

    def eating(self):
        self.schedule.destroy()
        self.button_1.destroy()
        self.button_2.destroy()
        self.button_3.destroy()
        self.button_4.destroy()
        self.button_fest.destroy()

        self.act_count += 1

        self.label_1 = Label(self, font=("굴림 20 bold"), text="밥을 먹고 힘 좀 내볼까요?")
        self.label_2 = Label(self, font=("굴림 20 bold"), text="어떻게 밥을 해결할까요?")
        self.button_5 = Button(self, font=("굴림 15 bold"), text="학교 밖", command=self.eating_1)
        self.button_6 = Button(self, font=("굴림 15 bold"), text="학생 식당", command=self.eating_2)
        self.button_7 = Button(self, font=("굴림 15 bold"), text="도시락", command=self.eating_3)

        self.label_1.grid(row=1, column=2, padx=20, pady=5)
        self.label_2.grid(row=2, column=2, padx=20, pady=5)
        self.button_5.grid(row=3, column=2, pady=10)
        self.button_6.grid(row=4, column=2, pady=10)
        self.button_7.grid(row=5, column=2, pady=10)

    #학교 밖

    def eating_1(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()

        self.label_3 = Label(self, font=("굴림 20 bold"), text="가고 싶은 식당이 어디인가요?")
        self.button_8 = Button(self, font=("굴림 15 bold"), text="알촌", command=self.alchon)
        self.button_9 = Button(self, font=("굴림 15 bold"), text="플랜비", command=self.planb)
        self.button_10 = Button(self, font=("굴림 15 bold"), text="일미닭갈비", command=self.illmi)
        self.button_11 = Button(self, font=("굴림 15 bold"), text="에비수", command=self.ebisu)
        self.button_12 = Button(self, font=("굴림 15 bold"), text="찌개찌개", command=self.jjigae)

        self.label_3.grid(row=1, column=2, padx=10, pady=10)
        self.button_8.grid(row=2, column=2, pady=10)
        self.button_9.grid(row=3, column=2, pady=10)
        self.button_10.grid(row=4, column=2, pady=10)
        self.button_11.grid(row=5, column=2, pady=10)
        self.button_12.grid(row=6, column=2, pady=10)

    #알촌

    def alchon(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_4 = Label(self, font=("굴림 15 bold"), text="드시고 싶은 메뉴를 선택하세요.")
        self.button_13 = Button(self, font=("굴림 12 bold"), text="순한 알밥 (3,800원)", command=self.sunhan)
        self.button_14 = Button(self, font=("굴림 12 bold"), text="카레 알밥 (4,300원)", command=self.kare)
        self.button_15 = Button(self, font=("굴림 12 bold"), text="갈릭 치즈 알밥 (4,800원)", command=self.galchi)

        self.label_4.grid(row=1, column=2, padx=10, pady=10)
        self.button_13.grid(row=2, column=2, pady=10)
        self.button_14.grid(row=3, column=2, pady=10)
        self.button_15.grid(row=4, column=2, pady=10)

    def sunhan(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        image = Image.open("알촌_순한알밥.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_6 = Label(self, font=("굴림 15 bold"), text="맛있어!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 3증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 3,800원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 3
        self.money -= 3800

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def kare(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        image = Image.open("알촌_카레알밥.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_6 = Label(self, font=("굴림 15 bold"), text="카레와 알밥의 조화가 환상적이네!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 4증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 4,300원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 4
        self.money -= 4300

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def galchi(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        image = Image.open("알촌_갈릭치즈알밥.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_6 = Label(self, font=("굴림 15 bold"), text="치즈가 쭉쭉 늘어나네!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 4증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 4,800원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 4
        self.money -= 4800

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    #플랜비

    def planb(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_4 = Label(self, font=("굴림 15 bold"), text="드시고 싶은 메뉴를 선택하세요.")
        self.button_13 = Button(self, font=("굴림 12 bold"), text="치킨 라이스 (3,000원)", command=self.chira)
        self.button_14 = Button(self, font=("굴림 12 bold"), text="치킨 감자 (3,500원)", command=self.chigam)
        self.button_15 = Button(self, font=("굴림 12 bold"), text="소고기 라이스 (3,000원)", command=self.sora)

        self.label_4.grid(row=1, column=2, padx=10, pady=10)
        self.button_13.grid(row=2, column=2, pady=10)
        self.button_14.grid(row=3, column=2, pady=10)
        self.button_15.grid(row=4, column=2, pady=10)

    def chira(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("플랜비_치킨라이스.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="간편하게 먹었다.")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 3증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 3,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 3
        self.money -= 3000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def chigam(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("플랜비_치킨감자.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="역시 플랜비는 치킨감자야!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 3증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 3,500원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 3
        self.money -= 3500

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def sora(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("플랜비_소고기라이스.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="소고기도 치킨 못지않게 맛있네!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 3증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 3,500원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.image.destroy()
        self.label_5.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 3
        self.money -= 3500

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    #일미닭갈비

    def illmi(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_4 = Label(self, font=("굴림 15 bold"), text="드시고 싶은 메뉴를 선택하세요.")
        self.button_13 = Button(self, font=("굴림 12 bold"), text="닭갈비 (6,500원)", command=self.chicken)
        self.button_14 = Button(self, font=("굴림 12 bold"), text="오징어 (7,000원)", command=self.squid)
        self.button_15 = Button(self, font=("굴림 12 bold"), text="닭갈비.삼겹살 (7,500원)", command=self.chisam)

        self.label_4.grid(row=1, column=2, padx=10, pady=10)
        self.button_13.grid(row=2, column=2, pady=10)
        self.button_14.grid(row=3, column=2, pady=10)
        self.button_15.grid(row=4, column=2, pady=10)

    def chicken(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("일미미_닭갈비.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="역시 일미 닭갈비는 최고야!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 6증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 6,500원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 6
        self.money -= 6500

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def squid(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("일미_오징어닭갈비.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="쫄깃한 오징어 볶음이 정말 맛있었다!")
        self.label_7 = Label(self, font=("굴림 15 bold") ,text="체력이 7증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 7,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 7
        self.money -= 7000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def chisam(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("일미_삼겹살.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="닭갈비와 삼겹살의 조화가 환상적이었다!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 7증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 7,500원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 7
        self.money -= 7500

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    #에비수

    def ebisu(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_4 = Label(self, font=("굴림 15 bold"), text="드시고 싶은 메뉴를 선택하세요.")
        self.button_13 = Button(self, font=("굴림 12 bold"), text="회덮밥 (6,000원)", command=self.sushi)
        self.button_14 = Button(self, font=("굴림 12 bold"), text="가츠동 (7,000원)", command=self.gattsu)
        self.button_15 = Button(self, font=("굴림 12 bold"), text="에비동 (9,000원)", command=self.ebi)

        self.label_4.grid(row=1, column=2, padx=10, pady=10)
        self.button_13.grid(row=2, column=2, pady=10)
        self.button_14.grid(row=3, column=2, pady=10)
        self.button_15.grid(row=4, column=2, pady=10)

    def sushi(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("에비수_회덮밥.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="상큼하게 먹은 한 끼였다!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 6증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 6,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 6
        self.money -= 6000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def gattsu(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("에비수_가츠돈.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="두툼한 돈까스가 정말 맛있었다.")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 7증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 7,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 7
        self.money -= 7000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def ebi(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("에비수_에비동.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="큼직한 새우튀김이 맛있었다!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 9증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 9,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 9
        self.money -= 9000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    #찌개찌개

    def jjigae(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_4 = Label(self, font=("굴림 15 bold"), text="드시고 싶은 메뉴를 선택하세요.")
        self.button_13 = Button(self, text="부대찌개 (6,000원)", command=self.budae)
        self.button_14 = Button(self, text="김치찌개 (6,000원)", command=self.gimchi)
        self.button_15 = Button(self, text="바지락순두부찌개 (6,000원)", command=self.bazirak)

        self.label_4.grid(row=1, column=2, padx=10, pady=10)
        self.button_13.grid(row=2, column=2, pady=10)
        self.button_14.grid(row=3, column=2, pady=10)
        self.button_15.grid(row=4, column=2, pady=10)

    def budae(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("찌개찌개개_부대찌개.jg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="햄과 소시지가 가득 들었네!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 6증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 6,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 6
        self.money -= 6000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def gimchi(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("찌개찌개_김치찌개.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="기본에 충실한 맛!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 6증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 6,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 6
        self.money -= 6000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def bazirak(self):
        self.label_4.destroy()
        self.button_13.destroy()
        self.button_14.destroy()
        self.button_15.destroy()

        image = Image.open("찌개찌개_순두부.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="맛있게 한 끼를 해결했다!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 6증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 6,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 6
        self.money -= 6000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    #학식

    def eating_2(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="메뉴를 선택해주세요!")
        self.button_8 = Button(self, font=("굴림 12 bold"), text="닭곰탕 (3,000원)", command=self.dakgom)
        self.button_9 = Button(self, font=("굴림 12 bold"), text="백선생짜글이 (3,500원)", command=self.backjja)
        self.button_10 = Button(self, font=("굴림 12 bold"), text="돈가스 (3,500원)", command=self.dongatsu)

        self.label_3.grid(row=1, column=2, padx=10, pady=10)
        self.button_8.grid(row=2, column=2, pady=10)
        self.button_9.grid(row=3, column=2, pady=10)
        self.button_10.grid(row=4, column=2, pady=10)

    def dakgom(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        image = Image.open("학생식당_닭곰탕.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="닭고기가 적었지만 괜찮았다!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 3증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 3,000원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 3
        self.money -= 3000

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def backjja(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        image = Image.open("학생식당_짜글이.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="조금 짜지만 맛있었다!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 3증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 3,500원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 3
        self.money -= 3500

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def dongatsu(self):
        self.label_3.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        image = Image.open("학생식당_돈까스.jpg")
        alchon_image = ImageTk.PhotoImage(image)
        self.image = Label(self, image=alchon_image)
        self.label_5 = Label(self, font=("굴림 15 bold"), text="먹는중...")
        self.label_6 = Label(self, font=("굴림 15 bold"), text="저렴한 가격에 괜찮게 먹었다!")
        self.label_7 = Label(self, font=("굴림 15 bold"), text="체력이 3증가!")
        self.label_8 = Label(self, font=("굴림 15 bold"), text="돈이 3,500원 감소!")

        self.label_5.grid(row=1, column=2, padx=10, pady=20)
        self.image.grid(row=2, rowspan=6, column=2, padx=10, pady=20)

        root.after(3000, self.update())

        self.label_5.destroy()
        self.image.destroy()
        self.label_6.grid(row=1, column=2, padx=10, pady=20)
        self.label_7.grid(row=2, column=2, padx=10, pady=20)
        self.label_8.grid(row=3, column=2, padx=10, pady=20)

        root.after(1500, self.update())

        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()

        self.stamina += 3
        self.money -= 3500

        self.stm.configure(text="체력 : "+str(self.stamina))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    #도시락

    def eating_3(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="도시락 냠냠!")
        self.label_4 = Label(self, font=("굴림 15 bold"), text="체력이 1증가!")

        self.label_3.grid(row=1, column=1, padx=10, pady=20)
        self.label_4.grid(row=2, column=1, padx=10, pady=20)

        root.after(1000, self.update())

        self.stamina += 1

        self.stm.configure(text="체력 : "+str(self.stamina))

        self.label_3.destroy()
        self.label_4.destroy()
        self.menu()

    #여가활동

    def activity(self):
        self.button_1.destroy()
        self.button_2.destroy()
        self.button_3.destroy()
        self.button_4.destroy()
        self.schedule.destroy()
        self.button_fest.destroy()

        self.act_count += 1

        self.label_1 = Label(self, font=("굴림 20 bold"), text="스트레스를 해소하자!")
        self.label_2 = Label(self, font=("굴림 20 bold"), text="어떻게 해소할까?")
        self.button_5 = Button(self, font=("굴림 15 bold"), text="술 마시기", command=self.alcohol)
        self.button_6 = Button(self, font=("굴림 15 bold"), text="봉사 활동", command=self.volunteer)
        self.button_7 = Button(self, font=("굴림 15 bold"), text="옷 사기", command=self.clothes)
        self.button_8 = Button(self, font=("굴림 15 bold"), text="산책", command=self.sanchak)
        self.button_9 = Button(self, font=("굴림 15 bold"), text="공연 관람", command=self.concert)
        self.button_10 = Button(self, font=("굴림 15 bold"), text="댄스 학원", command=self.dance)

        self.label_1.grid(row=1, column=2, padx=20, pady=5)
        self.label_2.grid(row=2, column=2, padx=20, pady=5)
        self.button_5.grid(row=3, column=2, pady=10)
        self.button_6.grid(row=4, column=2, pady=10)
        self.button_7.grid(row=5, column=2, pady=10)
        self.button_8.grid(row=6, column=2, pady=10)
        self.button_9.grid(row=7, column=2, pady=10)
        self.button_10.grid(row=8, column=2, pady=10)

    def alcohol(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        self.label_3 = Label(self, font=("굴림 15"), text="술을 마시고 새내기가 꼴았습니다!")
        self.label_4 = Label(self, font=("굴림 15"), text="판단력이 흐려져 지력이 15만큼 감소했습니다.")
        self.label_5 = Label(self, font=("굴림 15"), text="인성이 10만큼 감소했습니다.")
        self.label_6 = Label(self, font=("굴림 15"), text="숙취로 인해 체력이 30만큼 감소했습니다.")
        self.label_7 = Label(self, font=("굴림 15"), text="스트레스가 오히려 10만큼 증가했습니다!")
        self.label_8 = Label(self, font=("굴림 15"), text="술값으로 10000원을 지출했습니다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)
        self.label_4.grid(row=2, column=2, padx=5, pady=5)
        self.label_5.grid(row=3, column=2, padx=5, pady=5)
        self.label_6.grid(row=4, column=2, padx=5, pady=5)
        self.label_7.grid(row=5, column=2, padx=5, pady=5)
        self.label_8.grid(row=6, column=2, padx=5, pady=5)

        root.after(3000, self.update())

        self.label_3.destroy()
        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()


        self.intellect -= 15
        self.character -= 10
        self.stress += 10
        self.stamina -= 30
        self.money -= 10000

        self.int.configure(text="지능 : " + str(self.intellect))
        self.cha.configure(text="인성 : " + str(self.character))
        self.str.configure(text="스트레스 : " + str(self.stress))
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.mon.configure(text="재력 : " + str(self.money))
        self.menu()

    def volunteer(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        self.label_3 = Label(self, font=("굴림 15"), text="봉사 후 뿌듯함 때문에 인성이 20만큼 증가했습니다.")
        self.label_4 = Label(self, font=("굴림 15"), text="일손을 돕느라 체력이 10만큼 다소 감소했습니다.")
        self.label_5 = Label(self, font=("굴림 15"), text="스트레스가 5만큼 증가했습니다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)
        self.label_4.grid(row=2, column=2, padx=5, pady=5)
        self.label_5.grid(row=3, column=2, padx=5, pady=5)

        root.after(2000, self.update())

        self.label_3.destroy()
        self.label_4.destroy()
        self.label_5.destroy()

        self.character += 20
        self.stress += 5
        self.stamina -= 10

        self.cha.configure(text="인성 : " + str(self.character))
        self.str.configure(text="스트레스 : " + str(self.stress))
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.menu()

    def clothes(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        self.label_3 = Label(self, font=("굴림 15"), text="매력이 20만큼 증가했습니다.")
        self.label_4 = Label(self, font=("굴림 15"), text="스트레스가 20만큼 감소했습니다.")
        self.label_5 = Label(self, font=("굴림 15"), text="옷값으로 30000원을 지출했습니다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)
        self.label_4.grid(row=2, column=2, padx=5, pady=5)
        self.label_5.grid(row=3, column=2, padx=5, pady=5)

        root.after(2000, self.update())

        self.label_3.destroy()
        self.label_4.destroy()
        self.label_5.destroy()

        self.attract += 20
        self.stress -= 20
        self.money -= 30000

        self.atr.configure(text="매력 : " + str(self.attract))
        self.str.configure(text="스트레스 : " + str(self.stress))
        self.mon.configure(text="재력 : " + str(self.money))
        self.menu()

    def sanchak(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        self.label_3 = Label(self, font=("굴림 15"), text="운동을 했더니 체력이 10만큼 증가하였습니다.")
        self.label_4 = Label(self, font=("굴림 15"), text="시원한 탄천을 걸었더니 스트레스가 5만큼 감소했습니다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)
        self.label_4.grid(row=2, column=2, padx=5, pady=5)

        root.after(2000, self.update())

        self.label_3.destroy()
        self.label_4.destroy()

        self.stamina += 10
        self.stress -= 5

        self.str.configure(text="스트레스 : " + str(self.stress))
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.menu()

    def concert(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        self.label_3 = Label(self, font=("굴림 15"), text="체력이 10만큼 감소하였습니다.")
        self.label_4 = Label(self, font=("굴림 15"), text="매력이 15만큼 증가하였습니다.")
        self.label_5 = Label(self, font=("굴림 15"), text="스트레스가 10만큼 감소하였습니다.")
        self.label_6 = Label(self, font=("굴림 15"), text="공연관람비로 50000원 지출했습니다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)
        self.label_4.grid(row=2, column=2, padx=5, pady=5)
        self.label_5.grid(row=3, column=2, padx=5, pady=5)
        self.label_6.grid(row=4, column=2, padx=5, pady=5)

        root.after(2000, self.update())

        self.label_3.destroy()
        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()

        self.stamina -= 10
        self.attract += 15
        self.stress -= 10
        self.money -= 50000

        self.str.configure(text="스트레스 : " + str(self.stress))
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.atr.configure(text="매력 : " + str(self.attract))
        self.mon.configure(text="재력 : " + str(self.money))
        self.menu()

    def dance(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()

        self.label_3 = Label(self, font=("굴림 15"), text="지력이 5만큼 증가하였습니다.")
        self.label_4 = Label(self, font=("굴림 15"), text="스트레스가 10만큼 감소하였습니다.")
        self.label_5 = Label(self, font=("굴림 15"), text="댄스학원 강습비로 30000원을 지출했습니다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)
        self.label_4.grid(row=2, column=2, padx=5, pady=5)
        self.label_5.grid(row=3, column=2, padx=5, pady=5)

        root.after(2000, self.update())

        self.label_3.destroy()
        self.label_4.destroy()
        self.label_5.destroy()

        self.intellect += 5
        self.stress -= 10
        self.money -= 30000

        self.int.configure(text="지능 : " + str(self.intellect))
        self.str.configure(text="스트레스 : " + str(self.stress))
        self.mon.configure(text="재력 : " + str(self.money))
        self.menu()

    #수업

    def lesson(self):
        self.button_1.destroy()
        self.button_2.destroy()
        self.button_3.destroy()
        self.button_4.destroy()
        self.schedule.destroy()
        self.button_fest.destroy()

        self.act_count += 1

        self.label_1 = Label(self, font=("굴림 15 bold"), text="어떤 수업을 들을까?")
        self.button_5 = Button(self, font=("굴림 12 bold"), text="말과 문화", command=self.malmun)
        self.button_6 = Button(self, font=("굴림 12 bold"), text="일반물리학실험", command=self.illmulsill)
        self.button_7 = Button(self, font=("굴림 12 bold"), text="일반물리학", command=self.illmul)
        self.button_8 = Button(self, font=("굴림 12 bold"), text="프로그래밍 기초", command=self.peugi)
        self.button_9 = Button(self, font=("굴림 12 bold"), text="미분적분학", command=self.calculus)
        self.button_10 = Button(self, font=("굴림 12 bold"), text="PBL", command=self.pbl)
        self.button_11 = Button(self, font=("굴림 12 bold"), text="창의융합설계", command=self.changyung)
        self.button_12 = Button(self, font=("굴림 12 bold"), text="논리학", command=self.logic)

        self.label_1.grid(row=1, column=2, padx=20, pady=5)
        self.button_5.grid(row=2, column=2, pady=10)
        self.button_6.grid(row=3, column=2, pady=10)
        self.button_7.grid(row=4, column=2, pady=10)
        self.button_8.grid(row=5, column=2, pady=10)
        self.button_9.grid(row=6, column=2, pady=10)
        self.button_10.grid(row=7, column=2, pady=10)
        self.button_11.grid(row=8, column=2, pady=10)
        self.button_12.grid(row=9, column=2, pady=10)

    def malmun(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 2상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="체력이 1감소했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 3상승했다.")
        self.label_7 = Label(self, font=("굴림 13 bold"), text="스트레스가 2증가했다.")
        self.label_8 = Label(self, font=("굴림 13 bold"), text="매력이 1증가했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)
        self.label_7.grid(row=4, column=2, padx=5, pady=5)
        self.label_8.grid(row=5, column=2, padx=5, pady=5)

        self.score += 2
        self.stamina -= 1
        self.intellect += 3
        self.stress += 2
        self.attract += 1

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.label_8.destroy()
        self.stm.configure(text="체력 : "+str(self.stamina))
        self.int.configure(text="지능 : "+str(self.intellect))
        self.str.configure(text="스트레스 : "+str(self.stress))
        self.atr.configure(text="매력 : "+str(self.attract))

        self.menu()

    def illmulsill(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 1상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="체력이 2감소했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 3상승했다.")
        self.label_7 = Label(self, font=("굴림 13 bold"), text="스트레스가 4증가했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)
        self.label_7.grid(row=4, column=2, padx=5, pady=5)

        self.score += 1
        self.stamina -= 2
        self.intellect += 3
        self.stress += 4

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.int.configure(text="지능 : " + str(self.intellect))
        self.str.configure(text="스트레스 : " + str(self.stress))

        self.menu()

    def illmul(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 3상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="체력이 5감소했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 5상승했다.")
        self.label_7 = Label(self, font=("굴림 13 bold"), text="스트레스가 4증가했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)
        self.label_7.grid(row=4, column=2, padx=5, pady=5)

        self.score += 3
        self.stamina -= 5
        self.intellect += 5
        self.stress += 4

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.int.configure(text="지능 : " + str(self.intellect))
        self.str.configure(text="스트레스 : " + str(self.stress))

        self.menu()

    def peugi(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 3상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="체력이 4감소했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 3상승했다.")
        self.label_7 = Label(self, font=("굴림 13 bold"), text="스트레스가 5증가했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)
        self.label_7.grid(row=4, column=2, padx=5, pady=5)

        self.score += 3
        self.stamina -= 4
        self.intellect += 3
        self.stress += 5

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.int.configure(text="지능 : " + str(self.intellect))
        self.str.configure(text="스트레스 : " + str(self.stress))

        self.menu()

    def calculus(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 3상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="체력이 3감소했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 3상승했다.")
        self.label_7 = Label(self, font=("굴림 13 bold"), text="스트레스가 5증가했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)
        self.label_7.grid(row=4, column=2, padx=5, pady=5)

        self.score += 3
        self.stamina -= 3
        self.intellect += 3
        self.stress += 5

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.int.configure(text="지능 : " + str(self.intellect))
        self.str.configure(text="스트레스 : " + str(self.stress))

        self.menu()

    def logic(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 3상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="체력이 3감소했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 3상승했다.")
        self.label_7 = Label(self, font=("굴림 13 bold"), text="스트레스가 4증가했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)
        self.label_7.grid(row=4, column=2, padx=5, pady=5)

        self.score += 3
        self.stamina -= 3
        self.intellect += 3
        self.stress += 4

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.stm.configure(text="체력 : " + str(self.stamina))
        self.int.configure(text="지능 : " + str(self.intellect))
        self.str.configure(text="스트레스 : " + str(self.stress))

        self.menu()

    def pbl(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 1상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="인성이 3상승했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 2상승했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)

        self.score += 1
        self.intellect += 2
        self.character += 3

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.cha.configure(text="인성 : " + str(self.character))
        self.int.configure(text="지능 : " + str(self.intellect))

        self.menu()

    def changyung(self):
        self.label_1.destroy()
        self.button_5.destroy()
        self.button_6.destroy()
        self.button_7.destroy()
        self.button_8.destroy()
        self.button_9.destroy()
        self.button_10.destroy()
        self.button_11.destroy()
        self.button_12.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="강의를 들었다.")
        self.label_4 = Label(self, font=("굴림 13 bold"), text="성적이 2상승했다.")
        self.label_5 = Label(self, font=("굴림 13 bold"), text="인성이 1상승했다.")
        self.label_6 = Label(self, font=("굴림 13 bold"), text="지력이 1상승했다.")
        self.label_7 = Label(self, font=("굴림 13 bold"), text="스트레스가 1증가했다.")

        self.label_3.grid(row=1, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.grid(row=1, column=2, padx=5, pady=5)
        self.label_5.grid(row=2, column=2, padx=5, pady=5)
        self.label_6.grid(row=3, column=2, padx=5, pady=5)
        self.label_7.grid(row=4, column=2, padx=5, pady=5)

        self.score += 2
        self.character += 1
        self.intellect += 1
        self.stress += 1

        root.after(1500, self.update())

        self.label_4.destroy()
        self.label_5.destroy()
        self.label_6.destroy()
        self.label_7.destroy()
        self.cha.configure(text="인성 : " + str(self.stamina))
        self.int.configure(text="지능 : " + str(self.intellect))
        self.str.configure(text="스트레스 : " + str(self.stress))

        self.menu()

    def propose(self):
        self.button_1.destroy()
        self.button_2.destroy()
        self.button_3.destroy()
        self.button_4.destroy()
        self.schedule.destroy()
        self.button_fest.destroy()

        self.act_count += 1

        self.label_1 = Label(self, font=("굴림 15 bold"), text="현재"+self.name+"에겐 좋아하는 사람이 있습니다.")
        self.label_2 = Label(self, font=("굴림 15 bold"), text="그 사람에게 고백합니다.")

        self.label_1.grid(row=1, column=2, padx=5, pady=5)
        self.label_2.grid(row=2, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        perclist = random.choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        if perclist == 1 or perclist == 2 or perclist == 3 or perclist == 4:
            self.label_1.destroy()
            self.label_2.destroy()

            self.label_3 = Label(self, font=("굴림 15 bold"), text="축하합니다! 고백에 성공하셨습니다.")
            self.label_4 = Label(self, font=("굴림 15 bold"), text="이제"+self.name+"은(는) 솔로가 아닙니다..!")
            self.label_5 = Label(self, font=("굴림 15 bold"), text="이제부터 연인과 데이트가 가능합니다!")

            self.label_3.grid(row=1, column=2, padx=5, pady=5)
            self.label_4.grid(row=2, column=2, padx=5, pady=5)
            self.label_5.grid(row=3, column=2, padx=5, pady=5)

            root.after(1500, self.update())

            self.label_3.destroy()
            self.label_4.destroy()
            self.label_5.destroy()

            self.love_count = 1

            self.menu()
        else:
            self.label_1.destroy()
            self.label_2.destroy()

            stat_down = random.choice([0, 1, 2, 3])

            self.label_3 = Label(self, font=("굴림 15 bold"), text="고백에 실패하셨습니다.")
            self.label_4 = Label(self, font=("굴림 15 bold"), text="솔로도 나쁘지 않아...")

            self.label_3.grid(row=1, column=2, padx=5, pady=5)
            self.label_4.grid(row=2, column=2, padx=5, pady=5)

            root.after(1500, self.update())

            self.label_5 = Label(self, font=("굴림 15 bold"), text="충격으로 랜덤 스탯 하나가 15감소합니다.")

            if stat_down == 0:
                self.stamina -= 15
                self.stm.configure(text="체력 : "+str(self.stamina))
            elif stat_down == 1:
                self.intellect -= 15
                self.int.configure(text="지능 : "+str(self.intellect))
            elif stat_down == 2:
                self.character -= 15
                self.cha.configure(text="인성 : "+str(self.character))
            elif stat_down == 3:
                self.attract -= 15
                self.atr.configure(text="매력 : "+str(self.attract))

            self.label_5.grid(row=1, column=2, padx=5, pady=5)
            self.label_3.destroy()
            self.label_4.destroy()

            root.after(1500, self.update())

            self.label_5.destroy()

            self.menu()

    def love(self):
        self.button_1.destroy()
        self.button_2.destroy()
        self.button_3.destroy()
        self.button_4.destroy()
        self.schedule.destroy()
        self.button_fest.destroy()

        self.act_count += 1

        self.label_1 = Label(self, font=("굴림 15 bold"), text="오늘은 데이트 하는 날!")
        self.label_2 = Label(self, font=("굴림 15 bold"), text="데이트 중입니다.")

        self.label_1.grid(row=1, column=2, padx=5, pady=5)
        self.label_2.grid(row=2, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_1.destroy()
        self.label_2.destroy()

        loveper = random.choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        if loveper == 1:
            self.label_3 = Label(self, font=("굴림 15 bold"), text="데이트에 성공하셨습니다.")
            self.label_4 = Label(self, font=("굴림 15 bold"), text="랜덤으로 스탯 한개가 30상승합니다!")

            self.label_3.grid(row=1, column=2, padx=5, pady=5)
            self.label_4.grid(row=2, column=2, padx=5, pady=5)

            stat_up = random.choice([0, 1, 2, 3])
            if stat_up == 0:
                self.stamina += 30
                self.stm.configure(text="체력 : "+str(self.stamina))
            elif stat_up == 1:
                self.intellect += 30
                self.int.configure(text="지능 : "+str(self.intellect))
            elif stat_up == 2:
                self.character += 30
                self.cha.configure(text="인성 : "+str(self.character))
            elif stat_up == 3:
                self.attract += 30
                self.atr.configure(text="매력 : "+str(self.attract))

            root.after(2000, self.update())

            self.label_3.destroy()
            self.label_4.destroy()

            self.menu()
        else:
            self.label_3 = Label(self, font=("굴림 15 bold"), text="데이트에 실패하셨습니다.")
            self.label_4 = Label(self, font=("굴림 15 bold"), text="랜덤으로 스탯 한개가 5감소합니다.")

            self.label_3.grid(row=1, column=2, padx=5, pady=5)
            self.label_4.grid(row=2, column=2, padx=5, pady=5)

            stat_up = random.choice([0, 1, 2, 3])
            if stat_up == 0:
                self.stamina -= 5
                self.stm.configure(text="체력 : " + str(self.stamina))
            elif stat_up == 1:
                self.intellect -= 5
                self.int.configure(text="지능 : " + str(self.intellect))
            elif stat_up == 2:
                self.character -= 5
                self.cha.configure(text="인성 : " + str(self.character))
            elif stat_up == 3:
                self.attract -= 5
                self.atr.configure(text="매력 : " + str(self.attract))

            root.after(2000, self.update())

            self.label_3.destroy()
            self.label_4.destroy()

            self.menu()

    def festival(self):
        self.button_1.destroy()
        self.button_2.destroy()
        self.button_3.destroy()
        self.button_4.destroy()
        self.schedule.destroy()
        self.button_fest.destroy()

        self.act_count += 1

        self.label_1 = Label(self, font=("굴림 15 bold"), text="즐거운 축제가 시작되었습니다.")
        self.label_2 = Label(self, font=("굴림 15 bold"), text="축제때는 주점을 즐기거나 장기자랑에 나갈 수 있습니다.")
        self.button_5 = Button(self, font=("굴림 12"), text="주점", command=self.jujum)
        self.button_6 = Button(self, font=("굴림 12"), text="장기자랑", command=self.janggi)

    def jujum(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text="마셔! 마셔! 먹고 죽어!")
        self.label_4 = Label(self, font=("굴림 15 bold"), text="스트레스가 50감소했다.")
        self.label_5 = Label(self, font=("굴림 15 bold"), text="재력이 50000원 감소했다.")
        self.label_3.grid(row=1, column=2, padx=5, pady=5)
        self.label_4.grid(row=2, column=2, padx=5, pady=5)
        self.label_5.grid(row=3, column=2, padx=5, pady=5)

        root.after(1500, self.update())

        self.label_3.destroy()
        self.label_4.destroy()
        self.label_5.destroy()

        self.stress -= 50
        self.money -= 50000

        self.str.configure(text="스트레스 : "+str(self.stress))
        self.mon.configure(text="재력 : "+str(self.money))
        self.menu()

    def janggi(self):
        self.label_1.destroy()
        self.label_2.destroy()
        self.button_5.destroy()
        self.button_6.destroy()

        self.label_3 = Label(self, font=("굴림 15 bold"), text=self.name+"은(는) 장기자랑에 나갔다!")
        self.label_3.grid(row=1, column=2, pasx=5, pady=5)

        root.after(1500, self.update())
        self.label_3.destroy()

        if self.character >= 200 and self.stamina >= 200 and self.intellect >= 200 and self.attract >= 200:
            self.label_4 = Label(self, font=("굴림 15 bold"), text="장기자랑에서 1등을 했다!")
            self.label_5 = Label(self, font=("굴림 15 bold"), text="상금으로 10만원을 얻었다!")

            self.label_4.grid(row=1, column=2, padx=5, pady=5)
            self.label_5.grid(row=2, column=2, padx=5, pady=5)

            root.after(1500, self.update())

            self.label_4.destroy()
            self.label_5.destroy()

            self.money += 100000

            self.mon.configure(text="재력 : "+str(self.money))
            self.menu()
        else:
            self.label_4 = Label(self, font=("굴림 15 bold"), text="아쉽게도 떨어졌다.")
            self.label_5 = Label(self, font=("굴림 15 bold"), text="내년을 노리자.")

            self.label_4.grid(row=1, column=2, padx=5, pady=5)
            self.label_5.grid(row=2, column=2, padx=5, pady=5)

            root.after(1500, self.update())

            self.label_4.destroy()
            self.label_5.destroy()
            self.menu()

    def delete(self):
        self.dt.destroy()
        self.stm.destroy()
        self.atr.destroy()
        self.int.destroy()
        self.cha.destroy()
        self.str.destroy()
        self.mon.destroy()

    def ending(self):
        s = self.stamina
        a = self.attract
        c = self.character
        i = self.intellect

        self.delete()

        label_end = Label(self, font=("돋움 48 bold"), text="종강 및 엔딩")
        label_end.grid(row=0, column=0)

        root.after(5000, self.update())

        label_end.destroy()

        if self.score < 80:
            if (s + a + c + i < 40):
                if self.gender == "남자":
                    image = Image.open("쪽박엔딩_범죄자_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("쪽박엔딩_범죄자_여자.jpeg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="범죄자").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="취업도 안되고 돈도 없던 새내기는 배고픈 나머지 빵을 훔쳐 징역을 살게 되었다.").grid(row=2,
                                                                                                           column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (40 <= s + a + c + i < 70):
                image = Image.open("쪽박엔딩_발냄새.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="학장님의 발냄새").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="답이 없는 자신의 학점을 보고 학장님께 죄송한 마음이 들어 새내기는 학장님의 발냄새가 되기로 했다!").grid(
                    row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (70 <= s + a + c + i < 100):
                if self.gender == "남자":
                    image = Image.open("쪽박엔딩_신용불량자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("쪽박엔딩_신용불량자_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="신용 불량자").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="할 일을 제쳐두고 매일 술을 마신 나머지 신용불량자가 되고 말았다..!").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (100 <= s + a + c + i < 130):
                if self.gender == "남자":
                    image = Image.open("쪽박엔딩_거지_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("쪽박엔딩_거지_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="거지").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="거지의 수입이 꽤 좋다는 것을 듣고 서울역 거지로 살고있다").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (130 <= s + a + c + i < 160):
                image = Image.open("쪽박엔딩_한줌의먼지.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="한줌의 먼지").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="새내기는 갖은 스트레스로 결국 한줌의 먼지가 되고 말았다…!").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (160 <= s + a + c + i < 190):
                if self.gender == "남자":
                    image = Image.open("쪽박엔딩_깡패_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("쪽박엔딩_깡패_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="깡패").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="한양대 사자상파 두목이 되었다!").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (190 <= s + a + c + i < 220):
                image = Image.open("쪽박엔딩_해변의모래알.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="해변의 모래알갱이").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"),
                      text="가까운 해변으로 놀러간 새내기 그는 지난날의 학포자로 산 자신을 돌아보게 되었고.. 그사이 모래알갱이가 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (220 <= s + a + c + i < 250):
                if self.gender == "남자":
                    image = Image.open("쪽박엔딩_사이비_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("쪽박엔딩_사이비_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="사이비 교단 회원").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"),
                      text="엘리트만을 요구하는 사회에 지쳐있던 새내기는 길에서 만난 한 아주머니의 전도로 자신의 인생을 이끌어줄 신을 만나게되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (250 <= s + a + c + i < 280):
                if self.gender == "남자":
                    image = Image.open("쪽박엔딩_사기꾼_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("쪽박엔딩_사기꾼_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="사기꾼").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="사회에 화가 난 나머지 인성이 삐뚤어져 남의 뒤통수를 쳐 먹고 살고있다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (280 <= s + a + c + i < 310):
                if self.gender == "남자":
                    image = Image.open("쪽박엔딩_백수_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("쪽박엔딩_백수_여자.jpeg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="만년 취준생 백수").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="집안 행사에 참여하지 못하고있다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (310 <= s + a + c + i < 340):
                image = Image.open("쪽박엔딩_군인말뚝.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="군대말뚝").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"),
                      text="군대에 지원해 군인 생활을 하다 사회에서 자신은 무능력한 존재라고 생각했고 그 뒤로 군대에 눌러 앉아버렸다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (340 <= s + a + c + i):
                image = Image.open("쪽박엔딩_학사경고.jpeg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="학사경고").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="아휴..새내기인데..").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
        elif 80 <= self.score < 600:
            if (c > i > a > s) or (c > a > i > s):
                image = Image.open("중박엔딩_신입사원.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="신입사원").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="대학 졸업 후 스펙을 갈고 닦아 괜찮은 기업에 입사했다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (s > a > c > i) or (s > c > a > i):
                image = Image.open("중박엔딩_맛집사장님.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="맛집 사장").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"),
                      text="날 때부터 지니고 있던 마법의 손으로 식당을 세워 신메뉴를 개발하여 혀를 내두를 만한 매출을 내고 있다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (a > c > i > s) or (a > i > c > s):
                image = Image.open("중박엔딩_파워블로거.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="파워블로거").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="자신이 지닌 지식을 공유하는 유익한 블로그를 운영하다 네x버 파워블로거에 선정되었다.").grid(row=2,
                                                                                                              column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (s > i > a > c) or (i > s > a > c):
                if gender == "남자":
                    image = Image.open("중박엔딩_유학생_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif gender == "여자":
                    image = Image.open("중박엔딩_유학생_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="유학생").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="학업에 집중하고 견문을 넓히기 위해 외국으로 유학을 떠났다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (i > a > c > s) or (i > c > a > s):
                image = Image.open("중박엔딩_공무원.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="공무원").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="몇 년간 공시 공부를 하여 공무원이 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (c > s > i > a) or (c > i > s > a):
                if gender == "남자":
                    image = Image.open("중박엔딩_선생님_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif gender == "여자":
                    image = Image.open("중박엔딩_선생님_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="학교 선생님").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="학생들을 가르치는 일이 좋아 교사가 되었다..").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (i > s > c > a) or (s > i > c > a):
                image = Image.open("중박엔딩_과탑.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="과탑").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="학업에 전념하다 보니 결국 과탑 자리를 차지하게 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (i > c > s > a) or (s > c > i > a):
                if gender == "남자":
                    image = Image.open("중박엔딩_게임개발자_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif gender == "여자":
                    image = Image.open("중박엔딩_게임개발자_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="게임 개발자").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="프로그래밍 공부를 열심히 하여 뛰어난 실력을 인정받아 게임 개발자가 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (s > a > i > c) or (i > a > s > c):
                if gender == "남자":
                    image = Image.open("중박엔딩_엔지니어_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif gender == "여자":
                    image = Image.open("중박엔딩_엔지니어_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="엔지니어").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="소프트웨어보다 하드웨어가 더 마음에 들어 엔지니어가 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (a > s > c > i) or (a > c > s > i):
                if gender == "남자":
                    image = Image.open("중박엔딩_모델_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif gender == "여자":
                    image = Image.open("중박엔딩_모델_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="모델").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="빼어난 미모를 살려 모델이 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (c > s > a > i) or (c > a > s > i):
                image = Image.open("중박엔딩_자원봉사자.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="자원봉사단 팀장").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="따뜻한 마음씨로 불우한 이웃들을 도우려 자원 봉사단에 들어갔다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (a > s > i > c) or (a > i > s > c):
                if gender == "남자":
                    image = Image.open("중박엔딩_무대기획자_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif gender == "여자":
                    image = Image.open("중박엔딩_무대기획자_여자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="무대 기획자").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="뛰어난 미적 센스를 발휘하여 무대 기획자로 취직했다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
        elif self.score >= 600:
            if (s > a > c > i) or (a > s > c > i):
                if self.gender == "남자":
                    image = Image.open("대박엔딩_금메달_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("대박엔딩_금메달_여자.jpeg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="올림픽 금메달리스트").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="뛰어난 체력과 운동능력을 바탕으로 20xx년 ㅇㅇ올림픽 ㅇㅇ종목에서 금메달을 획득했다.").grid(row=2,
                                                                                                               column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (s > i > a > c) or (i > s > a > c):
                image = Image.open("대박엔딩_로또.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="로또 100억 당첨").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="심심풀이로 산 로또에 당첨이 되어 아무 걱정 없이 살 수 있게 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (i > a > c > s) or (i > c > a > s):
                if self.gender == "남자":
                    image = Image.open("대박엔딩_ceo_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("대박엔딩_ceo_여자.jpeg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="세계적인 기업의 CEO").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="끊임없는 노력으로 자수성가한 CEO가 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (i > s > c > a) or (i > c > s > a):
                if self.gender == "남자":
                    image = Image.open("대박엔딩_노벨상_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("대박엔딩_노벨상_여자.jpeg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="노벨상 수상").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="명석한 두뇌로 연구를 계속한 끝에 공로를 인정받아 노벨ㅇㅇ상을 수상했다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (i > a > s > c) or (a > i > s > c):
                image = Image.open("대박엔딩_건물주.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="건물주").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="모아놓은 돈으로 산 건물의 가치가 급격하게 올라 부자가 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (a > i > c > s) or (a > c > i > s):
                if self.gender == "남자":
                    image = Image.open("대박엔딩_국가정상_남자.jpg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                elif self.gender == "여자":
                    image = Image.open("대박엔딩_국가정상_여자.jpeg")
                    use_image = ImageTk.PhotoImage(image)
                    self.image = Label(self, image=use_image)
                    self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="대통령").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="국가를 통솔하는 중대 임무를 맡은 대통령이 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (s > i > c > a) or (s > c > i > a):
                image = Image.open("대박엔딩_재벌2세결혼.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="재벌 2세와 결혼").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="우리나라 경제를 쥐락펴락하는 재벌 집안의 자식과 사랑에 빠져 결혼에 골인했다.").grid(row=2,
                                                                                                          column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (c > s > a > i) or (c > a > s > i):
                image = Image.open("대박엔딩_사자상.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="한양대의 사자상").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="한양대를 지키는 용맹하고 우람한 가끔씩 임플란트를 해야하는 사자상이 되었다.").grid(row=2,
                                                                                                         column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (c > i > a > s) or (c > a > i > s):
                image = Image.open("대박엔딩_un사무총장.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="UN사무총장").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="뛰어난 통솔력과 카리스마를 지닌 UN사무총장이 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (a > c > s > i) or (s > c > a > i):
                image = Image.open("대박엔딩_마이클잭슨.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="마이클 잭슨").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="전세계를 뒤흔든 대 스타가 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (c > i > s > a) or (c > s > i > a):
                image = Image.open("대박엔딩_수호신.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="한양대의 수호신").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="학교를 사랑하는 마음이 넘쳐흘러 모교를 수호하는 신이 되었다.").grid(row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()
            elif (s > a > i > c) or (a > s > i > c):
                image = Image.open("대박엔딩_우주정복.jpg")
                use_image = ImageTk.PhotoImage(image)
                self.image = Label(self, image=use_image)
                self.image.grid(row=1, column=0)
                Label(self, fg="red", font=("궁서 30 bold"), text="우주정복").grid(row=0, column=0)
                Label(self, font=("궁서 18 bold"), text="강력한 힘으로 지구, 태양계, 우리 은하를 차례로 정복하고 마침내 우주까지 손에 넣은 대군주가 되었다.").grid(
                    row=2, column=0)
                root.after(5000, self.update())
                self.destroy()
                self.quit()

title = Tk()
title.title("새내기부터 화석까지")
title.geometry("1024x720")
App_0(title)
title.mainloop()

ready = Tk()
ready.title("새내기부터 화석까지")
ready.geometry("640x320")
App_1(ready)
ready.mainloop()

root = Tk()
root.title("새내기부터 화석까지")
root.geometry("1024x640")
App(root)
root.mainloop()
